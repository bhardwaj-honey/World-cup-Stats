package com.worldcup2026.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorldCup2026ApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(WorldCup2026ApiApplication.class, args);
    }

}
