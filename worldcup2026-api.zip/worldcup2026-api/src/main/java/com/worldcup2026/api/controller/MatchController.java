package com.worldcup2026.api.controller;

import com.worldcup2026.api.model.Match;
import com.worldcup2026.api.service.MatchService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/matches")
public class MatchController {

    private final MatchService matchService;

    @Autowired
    public MatchController(MatchService matchService) {
        this.matchService = matchService;
    }

    // GET /api/matches (optionally ?teamId=1 or ?stage=Round of 32 or ?status=FINISHED)
    @GetMapping
    public ResponseEntity<List<Match>> getAllMatches(
            @RequestParam(required = false) Long teamId,
            @RequestParam(required = false) String stage,
            @RequestParam(required = false) Match.MatchStatus status) {

        if (teamId != null) {
            return ResponseEntity.ok(matchService.getMatchesByTeam(teamId));
        }
        if (stage != null && !stage.isBlank()) {
            return ResponseEntity.ok(matchService.getMatchesByStage(stage));
        }
        if (status != null) {
            return ResponseEntity.ok(matchService.getMatchesByStatus(status));
        }
        return ResponseEntity.ok(matchService.getAllMatches());
    }

    // GET /api/matches/{id}
    @GetMapping("/{id}")
    public ResponseEntity<Match> getMatchById(@PathVariable Long id) {
        return ResponseEntity.ok(matchService.getMatchById(id));
    }

    // POST /api/matches?homeTeamId=1&awayTeamId=2
    @PostMapping
    public ResponseEntity<Match> createMatch(
            @Valid @RequestBody Match match,
            @RequestParam Long homeTeamId,
            @RequestParam Long awayTeamId) {
        Match saved = matchService.createMatch(match, homeTeamId, awayTeamId);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    // PUT /api/matches/{id}?homeTeamId=1&awayTeamId=2  (team params optional on update)
    @PutMapping("/{id}")
    public ResponseEntity<Match> updateMatch(
            @PathVariable Long id,
            @Valid @RequestBody Match match,
            @RequestParam(required = false) Long homeTeamId,
            @RequestParam(required = false) Long awayTeamId) {
        return ResponseEntity.ok(matchService.updateMatch(id, match, homeTeamId, awayTeamId));
    }

    // DELETE /api/matches/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMatch(@PathVariable Long id) {
        matchService.deleteMatch(id);
        return ResponseEntity.noContent().build();
    }
}
