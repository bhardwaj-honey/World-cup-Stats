package com.worldcup2026.api.service;

import com.worldcup2026.api.exception.ResourceNotFoundException;
import com.worldcup2026.api.model.Match;
import com.worldcup2026.api.model.Team;
import com.worldcup2026.api.repository.MatchRepository;
import com.worldcup2026.api.repository.TeamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MatchService {

    private final MatchRepository matchRepository;
    private final TeamRepository teamRepository;

    @Autowired
    public MatchService(MatchRepository matchRepository, TeamRepository teamRepository) {
        this.matchRepository = matchRepository;
        this.teamRepository = teamRepository;
    }

    public List<Match> getAllMatches() {
        return matchRepository.findAll();
    }

    public Match getMatchById(Long id) {
        return matchRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Match not found with id: " + id));
    }

    public List<Match> getMatchesByTeam(Long teamId) {
        return matchRepository.findByHomeTeamIdOrAwayTeamId(teamId, teamId);
    }

    public List<Match> getMatchesByStage(String stage) {
        return matchRepository.findByStage(stage);
    }

    public List<Match> getMatchesByStatus(Match.MatchStatus status) {
        return matchRepository.findByStatus(status);
    }

    public Match createMatch(Match match, Long homeTeamId, Long awayTeamId) {
        Team homeTeam = teamRepository.findById(homeTeamId)
                .orElseThrow(() -> new ResourceNotFoundException("Home team not found with id: " + homeTeamId));
        Team awayTeam = teamRepository.findById(awayTeamId)
                .orElseThrow(() -> new ResourceNotFoundException("Away team not found with id: " + awayTeamId));

        match.setHomeTeam(homeTeam);
        match.setAwayTeam(awayTeam);
        return matchRepository.save(match);
    }

    public Match updateMatch(Long id, Match updatedMatch, Long homeTeamId, Long awayTeamId) {
        Match match = getMatchById(id);

        match.setHomeScore(updatedMatch.getHomeScore());
        match.setAwayScore(updatedMatch.getAwayScore());
        match.setMatchDate(updatedMatch.getMatchDate());
        match.setStadium(updatedMatch.getStadium());
        match.setStage(updatedMatch.getStage());
        match.setStatus(updatedMatch.getStatus());

        if (homeTeamId != null) {
            Team homeTeam = teamRepository.findById(homeTeamId)
                    .orElseThrow(() -> new ResourceNotFoundException("Home team not found with id: " + homeTeamId));
            match.setHomeTeam(homeTeam);
        }
        if (awayTeamId != null) {
            Team awayTeam = teamRepository.findById(awayTeamId)
                    .orElseThrow(() -> new ResourceNotFoundException("Away team not found with id: " + awayTeamId));
            match.setAwayTeam(awayTeam);
        }

        return matchRepository.save(match);
    }

    public void deleteMatch(Long id) {
        Match match = getMatchById(id);
        matchRepository.delete(match);
    }
}
