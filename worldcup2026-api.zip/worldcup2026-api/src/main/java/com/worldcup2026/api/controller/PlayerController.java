package com.worldcup2026.api.controller;

import com.worldcup2026.api.model.Player;
import com.worldcup2026.api.service.PlayerService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/players")
public class PlayerController {

    private final PlayerService playerService;

    @Autowired
    public PlayerController(PlayerService playerService) {
        this.playerService = playerService;
    }

    // GET /api/players (optionally ?teamId=1 or ?search=messi)
    @GetMapping
    public ResponseEntity<List<Player>> getAllPlayers(
            @RequestParam(required = false) Long teamId,
            @RequestParam(required = false) String search) {

        if (teamId != null) {
            return ResponseEntity.ok(playerService.getPlayersByTeam(teamId));
        }
        if (search != null && !search.isBlank()) {
            return ResponseEntity.ok(playerService.searchPlayersByName(search));
        }
        return ResponseEntity.ok(playerService.getAllPlayers());
    }

    // GET /api/players/top-scorers -> "Golden Boot" style leaderboard
    @GetMapping("/top-scorers")
    public ResponseEntity<List<Player>> getTopScorers() {
        return ResponseEntity.ok(playerService.getTopScorers());
    }

    // GET /api/players/{id}
    @GetMapping("/{id}")
    public ResponseEntity<Player> getPlayerById(@PathVariable Long id) {
        return ResponseEntity.ok(playerService.getPlayerById(id));
    }

    // POST /api/players?teamId=1
    @PostMapping
    public ResponseEntity<Player> createPlayer(
            @Valid @RequestBody Player player,
            @RequestParam(required = false) Long teamId) {
        Player saved = playerService.createPlayer(player, teamId);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    // PUT /api/players/{id}?teamId=1
    @PutMapping("/{id}")
    public ResponseEntity<Player> updatePlayer(
            @PathVariable Long id,
            @Valid @RequestBody Player player,
            @RequestParam(required = false) Long teamId) {
        return ResponseEntity.ok(playerService.updatePlayer(id, player, teamId));
    }

    // DELETE /api/players/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePlayer(@PathVariable Long id) {
        playerService.deletePlayer(id);
        return ResponseEntity.noContent().build();
    }
}
