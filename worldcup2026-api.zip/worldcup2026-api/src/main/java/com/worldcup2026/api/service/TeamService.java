package com.worldcup2026.api.service;

import com.worldcup2026.api.exception.ResourceNotFoundException;
import com.worldcup2026.api.model.Team;
import com.worldcup2026.api.repository.TeamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeamService {

    private final TeamRepository teamRepository;

    @Autowired
    public TeamService(TeamRepository teamRepository) {
        this.teamRepository = teamRepository;
    }

    public List<Team> getAllTeams() {
        return teamRepository.findAll();
    }

    public Team getTeamById(Long id) {
        return teamRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Team not found with id: " + id));
    }

    public List<Team> getTeamsByGroup(String groupName) {
        return teamRepository.findByGroupName(groupName.toUpperCase());
    }

    public List<Team> getStandings() {
        return teamRepository.findAllByOrderByPointsDescGoalsForDesc();
    }

    public List<Team> searchTeamsByName(String name) {
        return teamRepository.findByNameContainingIgnoreCase(name);
    }

    public Team createTeam(Team team) {
        return teamRepository.save(team);
    }

    public Team updateTeam(Long id, Team updatedTeam) {
        Team team = getTeamById(id);

        team.setName(updatedTeam.getName());
        team.setCountryCode(updatedTeam.getCountryCode());
        team.setGroupName(updatedTeam.getGroupName());
        team.setFlagUrl(updatedTeam.getFlagUrl());
        team.setCoach(updatedTeam.getCoach());
        team.setMatchesPlayed(updatedTeam.getMatchesPlayed());
        team.setWins(updatedTeam.getWins());
        team.setDraws(updatedTeam.getDraws());
        team.setLosses(updatedTeam.getLosses());
        team.setGoalsFor(updatedTeam.getGoalsFor());
        team.setGoalsAgainst(updatedTeam.getGoalsAgainst());
        team.setPoints(updatedTeam.getPoints());

        return teamRepository.save(team);
    }

    public void deleteTeam(Long id) {
        Team team = getTeamById(id);
        teamRepository.delete(team);
    }
}
