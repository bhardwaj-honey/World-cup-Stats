package com.worldcup2026.api.repository;

import com.worldcup2026.api.model.Team;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TeamRepository extends JpaRepository<Team, Long> {

    List<Team> findByGroupName(String groupName);

    List<Team> findByNameContainingIgnoreCase(String name);

    List<Team> findAllByOrderByPointsDescGoalsForDesc();
}
