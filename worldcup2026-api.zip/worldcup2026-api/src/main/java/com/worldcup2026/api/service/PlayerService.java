package com.worldcup2026.api.service;

import com.worldcup2026.api.exception.ResourceNotFoundException;
import com.worldcup2026.api.model.Player;
import com.worldcup2026.api.model.Team;
import com.worldcup2026.api.repository.PlayerRepository;
import com.worldcup2026.api.repository.TeamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PlayerService {

    private final PlayerRepository playerRepository;
    private final TeamRepository teamRepository;

    @Autowired
    public PlayerService(PlayerRepository playerRepository, TeamRepository teamRepository) {
        this.playerRepository = playerRepository;
        this.teamRepository = teamRepository;
    }

    public List<Player> getAllPlayers() {
        return playerRepository.findAll();
    }

    public Player getPlayerById(Long id) {
        return playerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Player not found with id: " + id));
    }

    public List<Player> getPlayersByTeam(Long teamId) {
        return playerRepository.findByTeamId(teamId);
    }

    public List<Player> getTopScorers() {
        return playerRepository.findAllByOrderByGoalsDesc();
    }

    public List<Player> searchPlayersByName(String name) {
        return playerRepository.findByNameContainingIgnoreCase(name);
    }

    public Player createPlayer(Player player, Long teamId) {
        if (teamId != null) {
            Team team = teamRepository.findById(teamId)
                    .orElseThrow(() -> new ResourceNotFoundException("Team not found with id: " + teamId));
            player.setTeam(team);
        }
        return playerRepository.save(player);
    }

    public Player updatePlayer(Long id, Player updatedPlayer, Long teamId) {
        Player player = getPlayerById(id);

        player.setName(updatedPlayer.getName());
        player.setPosition(updatedPlayer.getPosition());
        player.setJerseyNumber(updatedPlayer.getJerseyNumber());
        player.setNationality(updatedPlayer.getNationality());
        player.setGoals(updatedPlayer.getGoals());
        player.setAssists(updatedPlayer.getAssists());
        player.setYellowCards(updatedPlayer.getYellowCards());
        player.setRedCards(updatedPlayer.getRedCards());
        player.setMatchesPlayed(updatedPlayer.getMatchesPlayed());

        if (teamId != null) {
            Team team = teamRepository.findById(teamId)
                    .orElseThrow(() -> new ResourceNotFoundException("Team not found with id: " + teamId));
            player.setTeam(team);
        }

        return playerRepository.save(player);
    }

    public void deletePlayer(Long id) {
        Player player = getPlayerById(id);
        playerRepository.delete(player);
    }
}
