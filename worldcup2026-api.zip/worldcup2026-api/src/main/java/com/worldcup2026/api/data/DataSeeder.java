package com.worldcup2026.api.data;

import com.worldcup2026.api.model.Match;
import com.worldcup2026.api.model.Player;
import com.worldcup2026.api.model.Team;
import com.worldcup2026.api.repository.MatchRepository;
import com.worldcup2026.api.repository.PlayerRepository;
import com.worldcup2026.api.repository.TeamRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Seeds the database with the real 48 teams / 12 groups of the 2026 FIFA World Cup
 * (Canada-Mexico-USA) so the API has realistic data to demo right away.
 *
 * NOTE: Match scores/statuses below are sample/illustrative data for demo purposes.
 * Feel free to update them through the API (PUT /api/matches/{id}) to reflect the
 * real, latest results as the tournament progresses.
 *
 * This only runs the FIRST time (when the "teams" table is empty), so it won't
 * duplicate data or overwrite anything you add/edit afterwards.
 */
@Component
public class DataSeeder implements CommandLineRunner {

    private final TeamRepository teamRepository;
    private final PlayerRepository playerRepository;
    private final MatchRepository matchRepository;

    public DataSeeder(TeamRepository teamRepository, PlayerRepository playerRepository, MatchRepository matchRepository) {
        this.teamRepository = teamRepository;
        this.playerRepository = playerRepository;
        this.matchRepository = matchRepository;
    }

    @Override
    public void run(String... args) {
        if (teamRepository.count() > 0) {
            System.out.println(">>> Database already has data, skipping seeding.");
            return;
        }

        System.out.println(">>> Seeding 2026 FIFA World Cup teams, players and matches...");

        Map<String, Team> teams = new HashMap<>();

        // --- Group A ---
        seedTeam(teams, "Mexico", "MEX", "A", "Javier Aguirre");
        seedTeam(teams, "South Africa", "RSA", "A", "Hugo Broos");
        seedTeam(teams, "South Korea", "KOR", "A", "Hong Myung-bo");
        seedTeam(teams, "Czech Republic", "CZE", "A", "Ivan Hasek");

        // --- Group B ---
        seedTeam(teams, "Canada", "CAN", "B", "Jesse Marsch");
        seedTeam(teams, "Bosnia and Herzegovina", "BIH", "B", "Sergej Barbarez");
        seedTeam(teams, "Qatar", "QAT", "B", "Julen Lopetegui");
        seedTeam(teams, "Switzerland", "SUI", "B", "Murat Yakin");

        // --- Group C ---
        seedTeam(teams, "Brazil", "BRA", "C", "Carlo Ancelotti");
        seedTeam(teams, "Morocco", "MAR", "C", "Walid Regragui");
        seedTeam(teams, "Haiti", "HAI", "C", "Sebastien Migne");
        seedTeam(teams, "Scotland", "SCO", "C", "Steve Clarke");

        // --- Group D ---
        seedTeam(teams, "United States", "USA", "D", "Mauricio Pochettino");
        seedTeam(teams, "Paraguay", "PAR", "D", "Gustavo Alfaro");
        seedTeam(teams, "Australia", "AUS", "D", "Tony Popovic");
        seedTeam(teams, "Turkey", "TUR", "D", "Vincenzo Montella");

        // --- Group E ---
        seedTeam(teams, "Germany", "GER", "E", "Julian Nagelsmann");
        seedTeam(teams, "Curacao", "CUW", "E", "Dick Advocaat");
        seedTeam(teams, "Ivory Coast", "CIV", "E", "Emerse Fae");
        seedTeam(teams, "Ecuador", "ECU", "E", "Sebastian Beccacece");

        // --- Group F ---
        seedTeam(teams, "Netherlands", "NED", "F", "Ronald Koeman");
        seedTeam(teams, "Japan", "JPN", "F", "Hajime Moriyasu");
        seedTeam(teams, "Sweden", "SWE", "F", "Jon Dahl Tomasson");
        seedTeam(teams, "Tunisia", "TUN", "F", "Sami Trabelsi");

        // --- Group G ---
        seedTeam(teams, "Belgium", "BEL", "G", "Rudi Garcia");
        seedTeam(teams, "Egypt", "EGY", "G", "Hossam Hassan");
        seedTeam(teams, "Iran", "IRN", "G", "Amir Ghalenoei");
        seedTeam(teams, "New Zealand", "NZL", "G", "Darren Bazeley");

        // --- Group H ---
        seedTeam(teams, "Spain", "ESP", "H", "Luis de la Fuente");
        seedTeam(teams, "Cape Verde", "CPV", "H", "Pedro Leitao Brito");
        seedTeam(teams, "Saudi Arabia", "KSA", "H", "Herve Renard");
        seedTeam(teams, "Uruguay", "URU", "H", "Marcelo Bielsa");

        // --- Group I ---
        seedTeam(teams, "France", "FRA", "I", "Didier Deschamps");
        seedTeam(teams, "Senegal", "SEN", "I", "Pape Thiaw");
        seedTeam(teams, "Iraq", "IRQ", "I", "Graham Arnold");
        seedTeam(teams, "Norway", "NOR", "I", "Stale Solbakken");

        // --- Group J ---
        seedTeam(teams, "Argentina", "ARG", "J", "Lionel Scaloni");
        seedTeam(teams, "Algeria", "ALG", "J", "Vladimir Petkovic");
        seedTeam(teams, "Austria", "AUT", "J", "Ralf Rangnick");
        seedTeam(teams, "Jordan", "JOR", "J", "Jamal Sellami");

        // --- Group K ---
        seedTeam(teams, "Portugal", "POR", "K", "Roberto Martinez");
        seedTeam(teams, "DR Congo", "COD", "K", "Sebastien Desabre");
        seedTeam(teams, "Uzbekistan", "UZB", "K", "Srecko Katanec");
        seedTeam(teams, "Colombia", "COL", "K", "Nestor Lorenzo");

        // --- Group L ---
        seedTeam(teams, "England", "ENG", "L", "Thomas Tuchel");
        seedTeam(teams, "Croatia", "CRO", "L", "Zlatko Dalic");
        seedTeam(teams, "Ghana", "GHA", "L", "Otto Addo");
        seedTeam(teams, "Panama", "PAN", "L", "Thomas Christiansen");

        // --- Sample star players for a handful of high-profile teams ---
        addPlayer(teams.get("Argentina"), "Lionel Messi", "Forward", 10, "Argentina");
        addPlayer(teams.get("Argentina"), "Julian Alvarez", "Forward", 9, "Argentina");
        addPlayer(teams.get("Argentina"), "Emiliano Martinez", "Goalkeeper", 23, "Argentina");

        addPlayer(teams.get("France"), "Kylian Mbappe", "Forward", 10, "France");
        addPlayer(teams.get("France"), "Ousmane Dembele", "Forward", 7, "France");

        addPlayer(teams.get("Portugal"), "Cristiano Ronaldo", "Forward", 7, "Portugal");
        addPlayer(teams.get("Portugal"), "Bruno Fernandes", "Midfielder", 8, "Portugal");

        addPlayer(teams.get("England"), "Harry Kane", "Forward", 9, "England");
        addPlayer(teams.get("England"), "Jude Bellingham", "Midfielder", 10, "England");

        addPlayer(teams.get("Brazil"), "Vinicius Junior", "Forward", 7, "Brazil");
        addPlayer(teams.get("Brazil"), "Rodrygo", "Forward", 11, "Brazil");

        addPlayer(teams.get("Spain"), "Lamine Yamal", "Forward", 19, "Spain");
        addPlayer(teams.get("Spain"), "Pedri", "Midfielder", 26, "Spain");

        addPlayer(teams.get("Netherlands"), "Virgil van Dijk", "Defender", 4, "Netherlands");
        addPlayer(teams.get("Netherlands"), "Memphis Depay", "Forward", 10, "Netherlands");

        addPlayer(teams.get("United States"), "Christian Pulisic", "Forward", 10, "United States");
        addPlayer(teams.get("United States"), "Folarin Balogun", "Forward", 9, "United States");

        addPlayer(teams.get("Mexico"), "Santiago Gimenez", "Forward", 11, "Mexico");
        addPlayer(teams.get("Mexico"), "Edson Alvarez", "Midfielder", 4, "Mexico");

        addPlayer(teams.get("Germany"), "Jamal Musiala", "Midfielder", 10, "Germany");
        addPlayer(teams.get("Germany"), "Florian Wirtz", "Midfielder", 17, "Germany");

        // --- Sample group-stage matches (illustrative; update via API with real results) ---
        seedMatch(teams.get("Mexico"), teams.get("South Africa"), 1, 1,
                LocalDateTime.of(2026, 6, 11, 19, 0), "Estadio Azteca, Mexico City", "Group A", Match.MatchStatus.FINISHED);
        seedMatch(teams.get("South Korea"), teams.get("Czech Republic"), 2, 1,
                LocalDateTime.of(2026, 6, 11, 22, 0), "Estadio Akron, Guadalajara", "Group A", Match.MatchStatus.FINISHED);

        seedMatch(teams.get("Canada"), teams.get("Bosnia and Herzegovina"), 2, 0,
                LocalDateTime.of(2026, 6, 12, 18, 0), "BMO Field, Toronto", "Group B", Match.MatchStatus.FINISHED);
        seedMatch(teams.get("United States"), teams.get("Paraguay"), 3, 1,
                LocalDateTime.of(2026, 6, 12, 21, 0), "SoFi Stadium, Los Angeles", "Group D", Match.MatchStatus.FINISHED);

        seedMatch(teams.get("Brazil"), teams.get("Morocco"), 2, 1,
                LocalDateTime.of(2026, 6, 13, 19, 0), "Lincoln Financial Field, Philadelphia", "Group C", Match.MatchStatus.FINISHED);

        seedMatch(teams.get("Argentina"), teams.get("Jordan"), 3, 0,
                LocalDateTime.of(2026, 6, 16, 19, 0), "Levi's Stadium, San Francisco", "Group J", Match.MatchStatus.FINISHED);
        seedMatch(teams.get("Portugal"), teams.get("Colombia"), 2, 2,
                LocalDateTime.of(2026, 6, 17, 21, 0), "Hard Rock Stadium, Miami", "Group K", Match.MatchStatus.FINISHED);
        seedMatch(teams.get("England"), teams.get("Croatia"), 1, 0,
                LocalDateTime.of(2026, 6, 17, 15, 0), "Gillette Stadium, Boston", "Group L", Match.MatchStatus.FINISHED);

        seedMatch(teams.get("Netherlands"), teams.get("Morocco"), 1, 1,
                LocalDateTime.of(2026, 6, 29, 18, 0), "AT&T Stadium, Dallas", "Round of 32", Match.MatchStatus.FINISHED);
        seedMatch(teams.get("France"), teams.get("Sweden"), 3, 1,
                LocalDateTime.of(2026, 6, 29, 21, 0), "MetLife Stadium, East Rutherford", "Round of 32", Match.MatchStatus.FINISHED);
        seedMatch(teams.get("Mexico"), teams.get("Ecuador"), 2, 1,
                LocalDateTime.of(2026, 6, 30, 20, 0), "Estadio Azteca, Mexico City", "Round of 32", Match.MatchStatus.FINISHED);

        // A couple of upcoming/scheduled matches (no scores yet)
        seedMatch(teams.get("Argentina"), teams.get("Algeria"), null, null,
                LocalDateTime.of(2026, 7, 4, 19, 0), "AT&T Stadium, Dallas", "Round of 16", Match.MatchStatus.SCHEDULED);
        seedMatch(teams.get("England"), teams.get("Senegal"), null, null,
                LocalDateTime.of(2026, 7, 5, 21, 0), "MetLife Stadium, East Rutherford", "Round of 16", Match.MatchStatus.SCHEDULED);

        System.out.println(">>> Seeding complete: " + teamRepository.count() + " teams, "
                + playerRepository.count() + " players, " + matchRepository.count() + " matches.");
    }

    private void seedTeam(Map<String, Team> teams, String name, String code, String group, String coach) {
        Team team = new Team(name, code, group, null, coach);
        team = teamRepository.save(team);
        teams.put(name, team);
    }

    private void addPlayer(Team team, String name, String position, int jerseyNumber, String nationality) {
        if (team == null) return;
        Player player = new Player(name, position, jerseyNumber, nationality, team);
        playerRepository.save(player);
    }

    private void seedMatch(Team home, Team away, Integer homeScore, Integer awayScore,
                            LocalDateTime date, String stadium, String stage, Match.MatchStatus status) {
        if (home == null || away == null) return;
        Match match = new Match(home, away, homeScore, awayScore, date, stadium, stage, status);
        matchRepository.save(match);

        // Update simple team stats for finished group-stage matches so /api/teams/standings looks realistic
        if (status == Match.MatchStatus.FINISHED && homeScore != null && awayScore != null) {
            updateTeamStats(home, homeScore, awayScore);
            updateTeamStats(away, awayScore, homeScore);
        }
    }

    private void updateTeamStats(Team team, int goalsFor, int goalsAgainst) {
        team.setMatchesPlayed(team.getMatchesPlayed() + 1);
        team.setGoalsFor(team.getGoalsFor() + goalsFor);
        team.setGoalsAgainst(team.getGoalsAgainst() + goalsAgainst);

        if (goalsFor > goalsAgainst) {
            team.setWins(team.getWins() + 1);
            team.setPoints(team.getPoints() + 3);
        } else if (goalsFor == goalsAgainst) {
            team.setDraws(team.getDraws() + 1);
            team.setPoints(team.getPoints() + 1);
        } else {
            team.setLosses(team.getLosses() + 1);
        }
        teamRepository.save(team);
    }
}
