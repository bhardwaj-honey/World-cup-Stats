package com.worldcup2026.api.repository;

import com.worldcup2026.api.model.Player;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PlayerRepository extends JpaRepository<Player, Long> {

    List<Player> findByTeamId(Long teamId);

    List<Player> findAllByOrderByGoalsDesc();

    List<Player> findByNameContainingIgnoreCase(String name);
}
