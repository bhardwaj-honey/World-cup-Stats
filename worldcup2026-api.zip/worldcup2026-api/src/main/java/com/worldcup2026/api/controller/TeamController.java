package com.worldcup2026.api.controller;

import com.worldcup2026.api.model.Team;
import com.worldcup2026.api.service.TeamService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/teams")
public class TeamController {

    private final TeamService teamService;

    @Autowired
    public TeamController(TeamService teamService) {
        this.teamService = teamService;
    }

    // GET /api/teams  -> list all teams (optionally ?group=A or ?search=brazil)
    @GetMapping
    public ResponseEntity<List<Team>> getAllTeams(
            @RequestParam(required = false) String group,
            @RequestParam(required = false) String search) {

        if (group != null && !group.isBlank()) {
            return ResponseEntity.ok(teamService.getTeamsByGroup(group));
        }
        if (search != null && !search.isBlank()) {
            return ResponseEntity.ok(teamService.searchTeamsByName(search));
        }
        return ResponseEntity.ok(teamService.getAllTeams());
    }

    // GET /api/teams/standings -> teams ordered by points/goals (like a group table)
    @GetMapping("/standings")
    public ResponseEntity<List<Team>> getStandings() {
        return ResponseEntity.ok(teamService.getStandings());
    }

    // GET /api/teams/{id}
    @GetMapping("/{id}")
    public ResponseEntity<Team> getTeamById(@PathVariable Long id) {
        return ResponseEntity.ok(teamService.getTeamById(id));
    }

    // POST /api/teams
    @PostMapping
    public ResponseEntity<Team> createTeam(@Valid @RequestBody Team team) {
        Team saved = teamService.createTeam(team);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    // PUT /api/teams/{id}
    @PutMapping("/{id}")
    public ResponseEntity<Team> updateTeam(@PathVariable Long id, @Valid @RequestBody Team team) {
        return ResponseEntity.ok(teamService.updateTeam(id, team));
    }

    // DELETE /api/teams/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTeam(@PathVariable Long id) {
        teamService.deleteTeam(id);
        return ResponseEntity.noContent().build();
    }
}
