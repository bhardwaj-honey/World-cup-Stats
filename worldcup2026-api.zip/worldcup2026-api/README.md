# FIFA World Cup 2026 Statistics API

A RESTful API built with **Java + Spring Boot** and **MySQL**, providing CRUD operations
and JSON data exchange for FIFA World Cup 2026 statistics — teams, players, and matches.

Built to match the assignment brief:
- ✅ RESTful API application using Java and Spring Boot
- ✅ CRUD operations with MySQL database integration and JSON data exchange
- ✅ Testable via Postman, structured for scalable backend functionality

The database comes pre-seeded with the **real 48 teams / 12 groups** of the 2026
World Cup (hosted by Canada, Mexico, and the USA) plus sample players and matches,
so you have realistic data to demo immediately.

---

## Project structure

```
worldcup2026-api/
├── pom.xml
├── WorldCup2026-API.postman_collection.json   ← import this into Postman
├── src/main/java/com/worldcup2026/api/
│   ├── WorldCup2026ApiApplication.java        ← main class, run this
│   ├── config/CorsConfig.java                 ← lets a frontend call the API
│   ├── exception/                             ← 404 / validation error handling
│   ├── model/                                 ← Team, Player, Match (JPA entities)
│   ├── repository/                            ← Spring Data JPA repositories
│   ├── service/                                ← business logic
│   ├── controller/                             ← REST endpoints
│   └── data/DataSeeder.java                    ← loads sample World Cup data on first run
└── src/main/resources/
    └── application.properties                  ← MySQL connection settings
```

---

## Prerequisites

1. **Java 17+** (JDK) — check with `java -version`
2. **Maven** (or just use the included Maven wrapper if you add one — VS Code's
   Java Extension Pack manages this automatically)
3. **MySQL Server** running locally (MySQL 8.x recommended)
4. **VS Code** with these extensions installed:
   - "Extension Pack for Java" (Microsoft)
   - "Spring Boot Extension Pack" (VMware)

---

## Setup (step by step)

### 1. Unzip the project and open it in VS Code
```
File → Open Folder → worldcup2026-api
```
VS Code should detect it as a Maven project automatically and start downloading
dependencies (watch the bottom-right progress notifications).

### 2. Create the MySQL database user/password you'll use
You don't need to manually create the `worldcup2026` database — the app will
create it for you on first run (`createDatabaseIfNotExist=true`). You just need
MySQL running and to know your **username/password**.

### 3. Configure your database credentials
Open `src/main/resources/application.properties` and update:
```properties
spring.datasource.username=root
spring.datasource.password=your_mysql_password
```
Replace with your actual local MySQL username/password.

### 4. Run the application
In VS Code:
- Open `WorldCup2026ApiApplication.java`
- Click the **"Run"** button above the `main` method (or press `F5`)

Or from a terminal inside the project folder:
```bash
mvn spring-boot:run
```

The first time it runs, you'll see console logs like:
```
>>> Seeding 2026 FIFA World Cup teams, players and matches...
>>> Seeding complete: 48 teams, 20 players, 13 matches.
```

The API is now running at: **http://localhost:8080**

---

## Testing the API

### Option A: Postman (as required by the assignment)
1. Open Postman
2. Import `WorldCup2026-API.postman_collection.json` (File → Import)
3. Try requests like "Get all teams", "Get standings", "Top scorers", etc.

### Option B: Just your browser (for GET requests)
- http://localhost:8080/api/teams
- http://localhost:8080/api/teams/standings
- http://localhost:8080/api/players/top-scorers
- http://localhost:8080/api/matches

---

## API Endpoints Reference

### Teams — `/api/teams`
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/teams` | List all teams |
| GET | `/api/teams?group=A` | Filter teams by group |
| GET | `/api/teams?search=brazil` | Search teams by name |
| GET | `/api/teams/standings` | Teams ordered by points (group table) |
| GET | `/api/teams/{id}` | Get one team |
| POST | `/api/teams` | Create a team |
| PUT | `/api/teams/{id}` | Update a team |
| DELETE | `/api/teams/{id}` | Delete a team |

### Players — `/api/players`
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/players` | List all players |
| GET | `/api/players?teamId=1` | Players on a specific team |
| GET | `/api/players?search=messi` | Search players by name |
| GET | `/api/players/top-scorers` | Leaderboard sorted by goals |
| GET | `/api/players/{id}` | Get one player |
| POST | `/api/players?teamId=1` | Create a player (attach to team) |
| PUT | `/api/players/{id}?teamId=1` | Update a player |
| DELETE | `/api/players/{id}` | Delete a player |

### Matches — `/api/matches`
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/matches` | List all matches |
| GET | `/api/matches?teamId=1` | Matches involving a team |
| GET | `/api/matches?stage=Group A` | Filter by stage |
| GET | `/api/matches?status=FINISHED` | Filter by status (`SCHEDULED`, `LIVE`, `FINISHED`) |
| GET | `/api/matches/{id}` | Get one match |
| POST | `/api/matches?homeTeamId=1&awayTeamId=2` | Create a match |
| PUT | `/api/matches/{id}` | Update a match (scores, status, etc.) |
| DELETE | `/api/matches/{id}` | Delete a match |

### Sample JSON bodies

**Create a team:**
```json
{
  "name": "Wales",
  "countryCode": "WAL",
  "groupName": "M",
  "coach": "Craig Bellamy"
}
```

**Create a player:**
```json
{
  "name": "New Player",
  "position": "Midfielder",
  "jerseyNumber": 8,
  "nationality": "Mexico"
}
```

**Create a match:**
```json
{
  "homeScore": 2,
  "awayScore": 1,
  "matchDate": "2026-06-20T18:00:00",
  "stadium": "Estadio Azteca, Mexico City",
  "stage": "Group A",
  "status": "FINISHED"
}
```

---

## Notes for your report / presentation

- **Layered architecture**: Controller → Service → Repository → Entity, following
  Spring Boot best practice for a scalable, maintainable backend.
- **CRUD**: every resource (Team, Player, Match) supports Create, Read, Update, Delete.
- **JSON data exchange**: all requests/responses use JSON automatically via Jackson.
- **MySQL integration**: Spring Data JPA + Hibernate auto-generates the schema
  from the entity classes (`spring.jpa.hibernate.ddl-auto=update`).
- **Error handling**: a global exception handler returns clean JSON errors
  (404 for missing resources, 400 for validation failures).
- **Sample data note**: the seeded match scores are illustrative demo data so the
  API has something to show immediately — update them via `PUT /api/matches/{id}`
  to reflect the actual, current results as the real tournament progresses.

## Troubleshooting

- **"Access denied for user"** → double check `spring.datasource.username` /
  `password` in `application.properties`.
- **"Unknown database"** → make sure MySQL is running; the app creates the
  database automatically on first successful connection.
- **Port 8080 already in use** → change `server.port` in `application.properties`.
- **Seed data not appearing** → seeding only runs once, when the `teams` table
  is empty. If you want to reseed, drop the `worldcup2026` database and restart.
